// JavaScript Document

document.getElementById("username").onchange = chkUsername;
document.getElementById("submitButton").onclick = chkPasswords;