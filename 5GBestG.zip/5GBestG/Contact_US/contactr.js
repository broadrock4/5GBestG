// JavaScript Document
document.getElementById("submitButton").onclick = chkUsername;